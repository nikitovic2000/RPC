package org.example.client;

import com.google.protobuf.Empty;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.example.rpc.*;
import org.example.rpc.Client;

import java.rmi.RemoteException;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;


public class ClientRCP {


    public static void main(String[] args) throws InterruptedException {

        CountDownLatch countDownLatch = new CountDownLatch(1);
        Thread thread = new Thread(new ClientTCP(countDownLatch));
        thread.start();
        countDownLatch.await();


        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8090).usePlaintext().build();

        RpcServiceGrpc.RpcServiceBlockingStub blockingStub = RpcServiceGrpc.newBlockingStub(channel);

        RpcServiceGrpc.RpcServiceStub asyncStub = RpcServiceGrpc.newStub(channel);

        Scanner scanner = new Scanner(System.in);



        System.out.println("Opcije: \n /sendPrivateMessage \n /createChatRoom \n /inviteUser \n /getChatRoomList \n /joinChatRoom \n /giveMeAllMessages \n i EXIT");
        String poruka = "";

        while (poruka.toLowerCase() != "exit") {

            poruka = scanner.nextLine();

            if (poruka.toLowerCase().equals("/sendprivatemessage")) {

                System.out.println("Format: username/soba ; poruka");
                poruka = scanner.nextLine();

                String[] por = poruka.split(";");
                String reciever = por[0];
                String message = por[1];

                ClientTCP.out.println(reciever + "; " + ClientTCP.username + ": " + message);



            } else if (poruka.toLowerCase().equals("/createchatroom")) {

                Client client = Client.newBuilder()
                        .setUsername(ClientTCP.username)
                        .build();

                Response response = blockingStub.createChatRoom(client);

                System.out.println(response);

            } else if (poruka.toLowerCase().equals("/inviteuser")) {

                System.out.println("Username korisnika, naziv sobe: ");

                poruka = scanner.nextLine();

                String[] mess = poruka.split(",");
                String user = mess[0];
                String soba = mess[1];

                CombinedRequest combinedRequest = CombinedRequest.newBuilder()
                        .setClient(Client.newBuilder().setUsername(user).build())
                        .setChatRoom(ChatRoom.newBuilder().setNaziv(soba).build())
                        .build();



                Response response = blockingStub.inviteUser(combinedRequest);
                System.out.println(response);


            } else if (poruka.toLowerCase().equals("/getchatroomlist")) {

                Response response = blockingStub.getChatRoomList(Empty.newBuilder().build());
                System.out.println(response);

            }else if(poruka.toLowerCase().equals("/joinchatroom")){

                System.out.println("Naziv sobe: ");
                poruka = scanner.nextLine();

                CombinedRequest combinedRequest = CombinedRequest.newBuilder()
                        .setClient(Client.newBuilder().setUsername(ClientTCP.username).build())
                        .setChatRoom(ChatRoom.newBuilder().setNaziv(poruka).build())
                        .build();

                Response response = blockingStub.joinChatRoom(combinedRequest);
                System.out.println(response);

            }else if(poruka.toLowerCase().equals("/givemeallmessages")){

                System.out.println("Naziv sobe: ");
                poruka = scanner.nextLine();

                ChatRoom chatRoom = ChatRoom.newBuilder()
                        .setNaziv(poruka)
                        .build();

                Response response = blockingStub.giveMeAllMessages(chatRoom);
                System.out.println(response);

            }else if(poruka.toLowerCase().equals("exit")){
                break;

            } else if (poruka.toLowerCase().equals("/editmessagee")) {

                System.out.println("ID poruke, Naziv Rooma, Nova poruka");

                poruka = scanner.nextLine();

                String[] mes = poruka.split(",");

                int id = Integer.parseInt(mes[0]);
                String naziv = mes[1];
                String poruk = mes[2];

                ID idd = ID.newBuilder().
                        setId(id)
                        .setRoom(naziv)
                        .setPor(poruk)
                        .build();

                Response response = blockingStub.editMessage(idd);
                System.out.println(response);

            } else {
                System.out.println("Nevazeca komanda!");
            }


        }

    }
}
