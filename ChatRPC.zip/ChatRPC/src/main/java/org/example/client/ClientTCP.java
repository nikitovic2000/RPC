package org.example.client;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class ClientTCP implements Runnable {



    public static final String lock = "LOCK";
    public static String username;

    private CountDownLatch countDownLatch;
    public ClientTCP(CountDownLatch countDownLatch){
        this.countDownLatch = countDownLatch;
    }

    public static PrintWriter out;

    @Override
     public void run() {


         try{

             Socket socket = new Socket("localhost", 9191);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

             Scanner scanner = new Scanner(System.in);


             String poruka;

             //poruka = in.readLine();

             poruka = in.readLine();
             System.out.println(poruka);


             while(username == null){
                 synchronized (lock) {
                     out.println(scanner.nextLine());
                     poruka = in.readLine();
                     if (poruka.equals("Korisnicko ime je zauteo, pokusajte sa nekim drugim.")) {
                         System.out.println(poruka);
                         // poruka = scanner.nextLine();
                         // System.out.println("if petlja");
                         //out.println(poruka);
                     } else {
                         username = poruka;
                         //System.out.println("Else petlja");
                         break;
                     }
                 }
             }

             System.out.println(in.readLine());
             countDownLatch.countDown();


//             PrintWriter finalOut = out;
//
////             Thread sendMessage = new Thread(new Runnable() {
////                 @Override
////                 public void run() {
////                     while (true) {
////
////
////
////                     }
////                 }
////             });


             BufferedReader finalIn = in;
             Thread readMessage = new Thread(new Runnable() {

                 @Override
                 public void run() {

                     while (true) {
                         try {

                             String msg = finalIn.readLine();
                             //System.out.println("Usao sam ovde - read");

                             System.out.println(msg);
                         } catch (IOException e) {

                             e.printStackTrace();
                         }
                     }
                 }
             });

//             sendMessage.start();
             readMessage.start();


         } catch (UnknownHostException e) {
             throw new RuntimeException(e);
         } catch (IOException e) {
             throw new RuntimeException(e);
         }

    }










}
