package org.example.client;

import java.io.PrintWriter;
import java.rmi.RemoteException;

public class Client {

    private PrintWriter out;
    private String username;

    public Client(String username, PrintWriter out){
        this.username = username;
        this.out = out;
    }



    public PrintWriter getOut() {
        return out;
    }

    public void setOut(PrintWriter out) {
        this.out = out;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
