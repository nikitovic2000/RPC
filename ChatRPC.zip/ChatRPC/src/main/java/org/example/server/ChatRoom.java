package org.example.server;

import java.util.ArrayList;

public class ChatRoom {

    private ArrayList<String> poruke;

    private ArrayList<String> korisnici;

    private String naziv;

    public ChatRoom(String naziv){
        this.poruke = new ArrayList<>();
        this.korisnici = new ArrayList<>();
        this.naziv = naziv;
    }

    public ArrayList<String> getPoruke() {
        return poruke;
    }

    public void setPoruke(ArrayList<String> poruke) {
        this.poruke = poruke;
    }

    public ArrayList<String> getKorisnici() {
        return korisnici;
    }

    public void setKorisnici(ArrayList<String> korisnici) {
        this.korisnici = korisnici;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
}
