package org.example.server;

import com.google.protobuf.Empty;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import org.example.rpc.*;

import java.io.IOException;
import java.util.ArrayList;

public class ServerRCP {

    public static ArrayList<ChatRoom> chatRooms = new ArrayList<>();


    public static void main(String[] args) throws IOException, InterruptedException {

        RpcServiceGrpc.RpcServiceImplBase rpcService = new RpcServiceGrpc.RpcServiceImplBase() {



            @Override
            public void createChatRoom(Client request, StreamObserver<Response> responseObserver) {
                ChatRoom chatRoom = new ChatRoom("Soba" + chatRooms.size());
                chatRoom.getKorisnici().add(request.getUsername());
                chatRooms.add(chatRoom);

                Response response = Response.newBuilder()
                        .setResponse("Soba uspesno kreirana, Naziv sobe: " + chatRoom.getNaziv())
                        .build();

                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }


            @Override
            public void inviteUser(CombinedRequest request, StreamObserver<Response> responseObserver) {

                Response response = Response.newBuilder()
                        .setResponse("Korisnik je vec u ChatRoom-u")
                        .build();

                for (ChatRoom chatRoom: chatRooms) {
                    if(request.getChatRoom().getNaziv().equals(chatRoom.getNaziv()) && !chatRoom.getKorisnici().contains(request.getClient().getUsername())){
                        chatRoom.getKorisnici().add((request.getClient().getUsername()));
                        response = Response.newBuilder()
                                .setResponse("Korisnik " + request.getClient().getUsername() + " dodat u ChatRoom: " + request.getChatRoom().getNaziv())
                                .build();
                    }
                }

                responseObserver.onNext(response);
                responseObserver.onCompleted();

            }

            @Override
            public void getChatRoomList(Empty request, StreamObserver<Response> responseObserver) {

                String lista = "";
                for(ChatRoom chatRoom: chatRooms){

                    lista += chatRoom.getNaziv() +",";
                }


                Response response = Response.newBuilder()
                        .setResponse(lista)
                        .build();


                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }

            @Override
            public void joinChatRoom(CombinedRequest request, StreamObserver<Response> responseObserver) {

                ArrayList<String> poruke = null;
                for (ChatRoom chatRoom: chatRooms) {
                    if(request.getChatRoom().getNaziv().equals(chatRoom.getNaziv())){
                        chatRoom.getKorisnici().add((request.getClient().getUsername()));

                        if(chatRoom.getPoruke().size() >=5) {
                            int velicina = chatRoom.getPoruke().size();
                            poruke = (ArrayList<String>) chatRoom.getPoruke().subList(Math.max(velicina - 5, 0), velicina);
                        }else{
                            poruke = chatRoom.getPoruke();
                        }

                    }
                }

                Response response;

                if(poruke.isEmpty()){

                    response = Response.newBuilder()
                            .setResponse("Uspesno ste pristipuli u ChatRoom: " + request.getChatRoom().getNaziv() + "\n" + "Cet je prazan.")
                            .build();

                }else {
                    response = Response.newBuilder()
                            .setResponse("Uspesno ste pristipuli u ChatRoom: " + request.getChatRoom().getNaziv() + "\n" + poruke)
                            .build();
                }

                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }

            @Override
            public void giveMeAllMessages(org.example.rpc.ChatRoom request, StreamObserver<Response> responseObserver) {

                ArrayList<String> poruke = null;

                for(ChatRoom chatRoom: chatRooms){
                    if(chatRoom.getNaziv().equals(request.getNaziv())){
                        poruke = chatRoom.getPoruke();
                    }
                }

                Response response = Response.newBuilder()
                        .setResponse(String.valueOf(poruke))
                        .build();

                responseObserver.onNext(response);
                responseObserver.onCompleted();

            }

            @Override
            public void editMessage(ID request, StreamObserver<Response> responseObserver) {
                for(ChatRoom chatRoom : chatRooms){
                    if(request.getRoom().equals(chatRoom.getNaziv())){
                        chatRoom.getPoruke().set((int) request.getId(), request.getPor() + "ED");
                    }
                }
                Response response = Response.newBuilder()
                        .setResponse("Uspesno zamenjena")
                        .build();

                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }
        };


        io.grpc.Server rpcServer = ServerBuilder.forPort(8090)
                .addService(rpcService)
                .build();


        rpcServer.start();
        rpcServer.awaitTermination();


    }

}
